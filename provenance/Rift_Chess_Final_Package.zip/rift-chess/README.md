# Rift Chess

**Move the piece. Or move the ground beneath it.**

A proposed offline 3D chess variant on fourteen sliding 2×2 tiles. Every turn is an ordinary chess move or one tile Shift. The selected rules allow empty tiles or one friendly non-king passenger, producing both transport tactics and changing lines of attack.

## Current status

This repository-ready package contains **the complete design handoff, executable Python rules/API reference, a local heuristic bot, tests, fixtures, and replayable experiments**. It does **not** yet contain a finished 3D game, installers, or player-tested release. The build-agent prompt below is the handoff for creating those. The project name is provisional; no name or trademark clearance is claimed.

The intended release is genuinely 3D: sculpted pieces, beveled sliding platforms, restrained cinematic lighting, selectable environments and piece styles, four useful camera presets plus free orbit, and movement/capture animation. Its gameplay, saves and AI must work offline. GitHub supplies source and downloads, not a required game server.

## Start here

- [Full rules](docs/01_RULES.md) and [play guide](docs/02_PLAY_GUIDE.md).
- [Visual analysis report — PDF](report/RIFT_CHESS_ANALYSIS.pdf), [self-contained HTML](report/RIFT_CHESS_ANALYSIS.html), or [accessible Markdown](report/RIFT_CHESS_ANALYSIS.md).
- [3D product and interaction design](docs/03_PRODUCT_DESIGN.md).
- [Engine, local AI, API and delivery design](docs/04_ENGINE_AND_DELIVERY.md).
- **[How the rules were chosen](docs/05_DECISION_NARRATIVE.md)** — the public decision narrative, including rejected ideas and evidence limitations.
- **[Build-agent prompt](docs/06_BUILD_AGENT_PROMPT.md)** — reads the package, proposes decisions for confirmation, then builds and actually play-tests the game.
- [Research sources](docs/RESEARCH_SOURCES.md) and [reference-code instructions](reference/README.md).

## Run the headless reference

Python 3.10 or newer is required for the reference; execution was verified on Python 3.13.5. Players of the eventual packaged game must **not** need Python, Node.js, or a developer toolchain.

```bash
python reference/rift_cli.py
```

The process accepts one JSON object per line and returns one JSON response per line. For example:

```json
{"id":1,"command":"new","layout":"B","draw_policy":"prompt"}
{"id":2,"command":"legal"}
{"id":3,"command":"step","action_id":20825,"revision":0}
{"id":4,"command":"suggest","depth":2,"max_nodes":3000,"seed":7}
{"id":5,"command":"export"}
```

The third request legally Shifts A2 into B2. No network endpoint, hosted model, login or runtime package download is used.

Install the development test dependency and verify:

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
python reference/verify_package.py
```

The included receipt records 67 passing tests. The verification run replayed 120 complete recorded histories, totaling 14,290 actions, and reproduced orthodox opening perft counts through depth 4. Fourteen named fixtures contain 223 expected successor positions for cross-language parity. These are concrete checks, not proof that every possible position is correct.

## Evidence, without inflated claims

There are two evidence tiers: inherited CSV summaries describing 4,560 old screening runs, and **120 newly run, fully replayable final-rules games**. Old simulation caps are not genuine draws. New records distinguish wins, draws and unfinished games explicitly.

The final rules are coherent enough to implement and test with players. Long-term fun, first-player advantage, strong-play balance, 3D readability and shipped performance remain unmeasured. The PDF explains what each result does and does not support.

## Origin, attribution and license handling

Inspired by [xkcd #3139, “Chess Variant”](https://xkcd.com/3139/). This is an independently specified implementation proposal, not an official xkcd or OpenAI product and not a claim to have invented sliding-tile chess. The [process narrative](docs/05_DECISION_NARRATIVE.md) notes existing implementations and distinguishes this ruleset.

The original comic is **not bundled**. Its [license](https://xkcd.com/license.html) is separate from any code or asset license. The build agent should propose MIT for original project code at the confirmation gate, then create the approved license and a third-party asset ledger before public release. Do not label third-party artwork or dependencies as original MIT assets.

## Support development

A donation link belongs here and in the finished game's About/title-screen footer once Hailey supplies the exact URL. The package intentionally contains no guessed payment address or fake destination. The application should hide the link while configuration is unset. Donations must not gate gameplay, features, cosmetics or AI.

## Implementation and publication

Use [the build prompt](docs/06_BUILD_AGENT_PROMPT.md) with the entire package. It requires a platform decision first, followed by confirmation before creating/publishing a repository. It also requires this README to be updated with **real** screenshots, tested launch instructions, release downloads, donation information, credits and honest platform support after implementation.

No GitHub repository or external resource was created by preparing this package. The requested creation and publication workflow is included in the build-agent prompt.
